<?php
get_header();
?>

<div class="row">
<div class="col">
<?php the_title( '<h1 class="entry-title">', '</h1>' );?>
<?php the_post_thumbnail(); ?>
<?php the_content(); ?>

<?php echo get_the_term_list( get_the_ID(), 'genero', '<div class="col">', ' , ', '</div>' );?>
<?php rwmb_the_value('status_manga'); ?>
<?php rwmb_the_value( 'tipo_manga' ); ?>
<?php rwmb_the_value('nome_alternativo'); ?>

<h1>Lista de Episodio</h1>
<?php list_chapter(get_the_ID(), 1000);?>

</div>
<div class="col-sm-3">
<?php get_sidebar(); ?>
</div>
</div>
<?php get_footer();?>