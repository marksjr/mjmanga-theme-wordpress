<?php
//CAMPUS PERSONALIZADOS

add_filter( 'rwmb_meta_boxes', 'your_prefix_register_meta_boxes' );
function your_prefix_register_meta_boxes( $meta_boxes )
{
	//$prefix = 'ero_';

	$meta_boxes[] = array(
		'id' => 'manga',
		'title' => __( 'Manga Info', 'meta-box' ),
		'pages' => array( 'manga' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(

			array(
				'name'  => __( 'Nome Alternativo', 'meta-box' ),
				'id'    => "nome_alternativo",
				'type'  => 'text',
			),
			array(
				'name'     => __( 'Tipo', 'meta-box' ),
				'id'       => "tipo_manga",
				'type'     => 'select',
				'options'  => array(
					'Manhwa' => __( 'Manhwa', 'meta-box' ),
					'Manhua' => __( 'Manhua', 'meta-box' ),
					'Manga' => __( 'Manga', 'meta-box' ),
					'Comic' => __( 'Comic', 'meta-box' ),
					'Novel' => __( 'Novel', 'meta-box' )
				),
				'multiple'    => false,
				'std'         => 'Manga',
			),
			array(
				'name'     => __( 'Status', 'meta-box' ),
				'id'       => "status_manga",
				'type'     => 'select',
				'options'  => array(
					'Em Lançamento' => __( 'Em Lançamento', 'meta-box' ),
					'Completo' => __( 'Completo', 'meta-box' ),
					'Hiatus' => __( 'Hiatus', 'meta-box' ),
				),
				'multiple'    => false,
				'std'         => 'Em Lançamento',
			),
         )
			
	);

	$meta_boxes[] = array(
		'id' => 'chapter',
		'title' => __( 'Configuração do Capítulo', 'meta-box' ),
	        'pages' => array( 'post' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name' => __( 'Nome do Capítulo', 'meta-box' ),
				'id'   => "nome_capitulo",
				'type' => 'text',
			),
			array(
				'name'    => __( 'Manga', 'meta-box' ),
				'id'      => "manga_pai",
				'type'    => 'post',

				// Post type
				'post_type' => 'manga',
				// Field type, either 'select' or 'select_advanced' (default)
				'field_type' => 'select_advanced',
				// Query arguments (optional). No settings means get all published posts
				'query_args' => array(
					'post_status'    => 'publish',
					'posts_per_page' => -1,
				)
			),
		)
	);
	return $meta_boxes;
}
//POST NEWS
add_action( 'init', 'post_new' );
function post_new() {
	$args = [
		'label'  => esc_html__( 'Post News', 'text-domain' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Post News', 'text-domain' ),
			'name_admin_bar'     => esc_html__( 'Post New', 'text-domain' ),
			'add_new'            => esc_html__( 'Add Post New', 'text-domain' ),
			'add_new_item'       => esc_html__( 'Add new Post New', 'text-domain' ),
			'new_item'           => esc_html__( 'New Post New', 'text-domain' ),
			'edit_item'          => esc_html__( 'Edit Post New', 'text-domain' ),
			'view_item'          => esc_html__( 'View Post New', 'text-domain' ),
			'update_item'        => esc_html__( 'View Post New', 'text-domain' ),
			'all_items'          => esc_html__( 'All Post News', 'text-domain' ),
			'search_items'       => esc_html__( 'Search Post News', 'text-domain' ),
			'parent_item_colon'  => esc_html__( 'Parent Post New', 'text-domain' ),
			'not_found'          => esc_html__( 'No Post News found', 'text-domain' ),
			'not_found_in_trash' => esc_html__( 'No Post News found in Trash', 'text-domain' ),
			'name'               => esc_html__( 'Post News', 'text-domain' ),
			'singular_name'      => esc_html__( 'Post New', 'text-domain' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => false,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 20,
		'menu_icon'           => 'dashicons-welcome-edit-page',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'comments',
		],
		'taxonomies' => [
			'category',
			'tag',
		],
		'rewrite' => true
	];

	register_post_type( 'post_new', $args );
}