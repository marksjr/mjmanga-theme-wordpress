<?php
//ADICONAR CAMPOS PERSONALIZADOS
add_action( 'init', 'manga' );
function manga() {
	$args = [
		'label'  => esc_html__( 'Mangas', 'text-domain' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Mangas', 'text_domain' ),
			'name_admin_bar'     => esc_html__( 'Manga', 'text_domain' ),
			'add_new'            => esc_html__( 'Add Manga', 'text_domain' ),
			'add_new_item'       => esc_html__( 'Add new Manga', 'text_domain' ),
			'new_item'           => esc_html__( 'New Manga', 'text_domain' ),
			'edit_item'          => esc_html__( 'Edit Manga', 'text_domain' ),
			'view_item'          => esc_html__( 'View Manga', 'text_domain' ),
			'update_item'        => esc_html__( 'View Manga', 'text_domain' ),
			'all_items'          => esc_html__( 'All Mangas', 'text_domain' ),
			'search_items'       => esc_html__( 'Search Mangas', 'text_domain' ),
			'parent_item_colon'  => esc_html__( 'Parent Manga', 'text_domain' ),
			'not_found'          => esc_html__( 'No Mangas found', 'text_domain' ),
			'not_found_in_trash' => esc_html__( 'No Mangas found in Trash', 'text_domain' ),
			'name'               => esc_html__( 'Mangas', 'text_domain' ),
			'singular_name'      => esc_html__( 'Manga', 'text_domain' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => true,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-book',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'comments',
			'page-attributes',
		],
		'taxonomies' => [
			'category',
			'tag',
			'genero'
		],
		'rewrite' => true
	];

	register_post_type( 'manga', $args );
}

//GENERO
add_action( 'init', 'genero' );
function genero() {
	$args = [
		'label'  => esc_html__( 'Generos', 'text_domain' ),
		'labels' => [
			'menu_name'                  => esc_html__( 'Generos', 'text_domain' ),
			'all_items'                  => esc_html__( 'All Generos', 'text_domain' ),
			'edit_item'                  => esc_html__( 'Edit Genero', 'text_domain' ),
			'view_item'                  => esc_html__( 'View Genero', 'text_domain' ),
			'update_item'                => esc_html__( 'Update Genero', 'text_domain' ),
			'add_new_item'               => esc_html__( 'Add new Genero', 'text_domain' ),
			'new_item'                   => esc_html__( 'New Genero', 'text_domain' ),
			'parent_item'                => esc_html__( 'Parent Genero', 'text_domain' ),
			'parent_item_colon'          => esc_html__( 'Parent Genero', 'text_domain' ),
			'search_items'               => esc_html__( 'Search Generos', 'text_domain' ),
			'popular_items'              => esc_html__( 'Popular Generos', 'text_domain' ),
			'separate_items_with_commas' => esc_html__( 'Separate Generos with commas', 'text_domain' ),
			'add_or_remove_items'        => esc_html__( 'Add or remove Generos', 'text_domain' ),
			'choose_from_most_used'      => esc_html__( 'Choose most used Generos', 'text_domain' ),
			'not_found'                  => esc_html__( 'No Generos found', 'text_domain' ),
			'name'                       => esc_html__( 'Generos', 'text_domain' ),
			'singular_name'              => esc_html__( 'Genero', 'text_domain' ),
		],
		'public'               => true,
		'show_ui'              => true,
		'show_in_menu'         => true,
		'show_in_nav_menus'    => true,
		'show_tagcloud'        => true,
		'show_in_quick_edit'   => true,
		'show_admin_column'    => false,
		'show_in_rest'         => true,
		'hierarchical'         => false,
		'query_var'            => true,
		'sort'                 => false,
		'rewrite_no_front'     => false,
		'rewrite_hierarchical' => false,
		'rewrite' => array( 'slug' => 'genero' ),
	];
	register_taxonomy( 'genero', [ 'manga' ], $args );
}





