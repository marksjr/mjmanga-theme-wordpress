<?php
get_header();
?>

<div class="row">
  <div class="col">
      <?php
      if ( have_posts() ) :  while ( have_posts() ) : the_post(); ?>
      <a href="<?php the_permalink(); ?>">
      <?php the_title('<h2>', '</h2>'); ?>
      </a>

      <?php
      //the_post_thumbnail(); 
      //the_excerpt();
      endwhile; 
      else: 
        _e( 'Sem Capítulo.', 'textdomain' ); 
      endif; 
      ?>
  </div>
  <div class="col-sm-3">
  <?php get_sidebar(); ?>
  </div>
</div>
<?php get_footer();?>