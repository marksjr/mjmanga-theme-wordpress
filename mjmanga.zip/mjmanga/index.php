<?php
get_header();
?>
<H1>Index</H1>