<?php
get_header();
?>
<h1>Home</h1>