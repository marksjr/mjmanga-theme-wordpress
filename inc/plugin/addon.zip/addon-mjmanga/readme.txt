=== Addon MJManga ===
Donate link: https://www.paypal.com/donate?business=WM3EY533MPMZU
Tags: manga, read, chapter
Requires at least: 5.5
Tested up to: 5.8
Stable tag: 5.4.2
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Addon Theme MJManga

== Description ==

add custom post, taxonomy and field

= Docs and support =

https://youtu.be/MctJkQ6fLeg

https://vendaon.xyz/downloads/addon-mj-manga-plugin/