<?php
/**
 * Addon MJManga
 *
 * Example plugin to demonstrate the ability to handle bundled plugins with the
 * TGM Plugin Activation library.
 *
 * @package     WordPress\Plugins\addon-mjmanga
 * @author      MJ On
 * @link        https://github.com/mj-on/mjmanga-theme-wordpress
 * @version     1.0
 * @copyright   2020 MJ On
 * @license     http://creativecommons.org/licenses/GPL/3.0/ GNU General Public License, version 3 or higher
 *
 * @wordpress-plugin
 * Plugin Name: Addon MJManga
 * Plugin URI:  https://vendaon.xyz/downloads/addon-mj-manga-plugin/
 * Description: Add Manga, Paging by Category page read
 * Author:      MJ On
 * Author URI:  https://vendaon.xyz
 * Version:     1.0
 * Text Domain: addon-mjmanga
 * Domain Path: /languages
 *
 */

// Avoid direct calls to this file.
if ( ! function_exists( 'add_action' ) ) {
	header( 'Status: 403 Forbidden' );
	header( 'HTTP/1.1 403 Forbidden' );
	exit();
}

if ( ! function_exists( 'tgm_php_mysql_versions' ) ) {

	add_action( 'rightnow_end', 'tgm_php_mysql_versions', 9 );

	function tgm_php_mysql_versions() {
		echo wp_kses(
			sprintf(
				/* TRANSLATORS: %1 = php version nr, %2 = mysql version nr. */
				__( '<p>You are running on <strong>PHP %1$s</strong> and <strong>MySQL %2$s</strong>.</p>', 'tgm-example-plugin' ),
				phpversion(),
				$GLOBALS['wpdb']->db_version()
			),
			array(
				'p' => array(),
				'strong' => array(),
			)
		);
	}
	
	add_filter( 'rwmb_meta_boxes', 'your_prefix_register_meta_boxes' );
function your_prefix_register_meta_boxes( $meta_boxes )
{
	//$prefix = 'ero_';

	$meta_boxes[] = array(
		'id' => 'manga',
		'title' => esc_html__( 'Manga Info', 'mjmanga' ),
		'pages' => array( 'manga' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(

			array(
				'name'  => esc_html__( 'Alternative Name', 'mjmanga' ),
				'id'    => "nome_alternativo",
				'type'  => 'text',
			),
			array(
				'name'     => esc_html__( 'Type', 'mjmanga' ),
				'id'       => "tipo_manga",
				'type'     => 'select',
				'options'  => array(
					'Manhwa' => esc_html__( 'Manhwa', 'mjmanga' ),
					'Manhua' => esc_html__( 'Manhua', 'mjmanga' ),
					'Manga' => esc_html__( 'Manga', 'mjmanga' ),
					'Comic' => esc_html__( 'Comic', 'mjmanga' ),
					'Novel' => esc_html__( 'Novel', 'mjmanga' )
				),
				'multiple'    => false,
				'std'         => 'Manga',
			),
			array(
				'name'     => esc_html__( 'Status', 'mjmanga' ),
				'id'       => "status_manga",
				'type'     => 'select',
				'options'  => array(
					'OnGoing' => esc_html__( 'OnGoing', 'mjmanga' ),
					'Complete' => esc_html__( 'Complete', 'mjmanga' ),
					'Hiatus' => esc_html__( 'Hiatus', 'mjmanga' ),
				),
				'multiple'    => false,
				'std'         => 'OnGoing',
			),
         )
			
	);

	$meta_boxes[] = array(
		'id' => 'chapter',
		'title' => esc_html__( 'Chapter Configuration', 'mjmanga' ),
	        'pages' => array( 'post' ),
		'context' => 'normal',
		'priority' => 'high',
		'autosave' => true,
		'fields' => array(
			array(
				'name' => esc_html__( 'Chapter Name', 'mjmanga' ),
				'id'   => "nome_capitulo",
				'type' => 'text',
			),
			array(
				'name'    => esc_html__( 'Manga', 'mjmanga' ),
				'id'      => "manga_pai",
				'type'    => 'post',

				// Post type
				'post_type' => 'manga',
				// Field type, either 'select' or 'select_advanced' (default)
				'field_type' => 'select_advanced',
				// Query arguments (optional). No settings means get all published posts
				'query_args' => array(
					'post_status'    => 'publish',
					'posts_per_page' => -1,
				)
			),
		)
	);
	return $meta_boxes;
}
//Blog
add_action( 'init', 'blog' );
function blog() {
	$args = [
		'label'  => esc_html__( 'Blog', 'mjmanga' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Blog', 'mjmanga' ),
			'name_admin_bar'     => esc_html__( 'Post New', 'mjmanga' ),
			'add_new'            => esc_html__( 'Add Post', 'mjmanga' ),
			'add_new_item'       => esc_html__( 'Add new Post ', 'mjmanga' ),
			'new_item'           => esc_html__( 'New Post', 'mjmanga' ),
			'edit_item'          => esc_html__( 'Edit Post', 'mjmanga' ),
			'view_item'          => esc_html__( 'View Post', 'mjmanga' ),
			'update_item'        => esc_html__( 'View Post', 'mjmanga' ),
			'all_items'          => esc_html__( 'All Blog', 'mjmanga' ),
			'search_items'       => esc_html__( 'Search Blog', 'mjmanga' ),
			'parent_item_colon'  => esc_html__( 'Parent Post New', 'mjmanga' ),
			'not_found'          => esc_html__( 'No Blog found', 'mjmanga' ),
			'not_found_in_trash' => esc_html__( 'No Blog found in Trash', 'mjmanga' ),
			'name'               => esc_html__( 'Blog', 'mjmanga' ),
			'singular_name'      => esc_html__( 'Post New', 'mjmanga' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => false,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 20,
		'menu_icon'           => 'dashicons-welcome-edit-page',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'comments',
		],
		'taxonomies' => [
			'category',
			'tag',
		],
		'rewrite' => true
	];

	register_post_type( 'blog', $args );
}

add_action( 'init', 'manga' );
function manga() {
	$args = [
		'label'  => esc_html__( 'Mangas', 'mjmanga' ),
		'labels' => [
			'menu_name'          => esc_html__( 'Mangas', 'mjmanga' ),
			'name_admin_bar'     => esc_html__( 'Manga', 'mjmanga' ),
			'add_new'            => esc_html__( 'Add Manga', 'mjmanga' ),
			'add_new_item'       => esc_html__( 'Add new Manga', 'mjmanga' ),
			'new_item'           => esc_html__( 'New Manga', 'mjmanga' ),
			'edit_item'          => esc_html__( 'Edit Manga', 'mjmanga' ),
			'view_item'          => esc_html__( 'View Manga', 'mjmanga' ),
			'update_item'        => esc_html__( 'View Manga', 'mjmanga' ),
			'all_items'          => esc_html__( 'All Mangas', 'mjmanga' ),
			'search_items'       => esc_html__( 'Search Mangas', 'mjmanga' ),
			'parent_item_colon'  => esc_html__( 'Parent Manga', 'mjmanga' ),
			'not_found'          => esc_html__( 'No Mangas found', 'mjmanga' ),
			'not_found_in_trash' => esc_html__( 'No Mangas found in Trash', 'mjmanga' ),
			'name'               => esc_html__( 'Mangas', 'mjmanga' ),
			'singular_name'      => esc_html__( 'Manga', 'mjmanga' ),
		],
		'public'              => true,
		'exclude_from_search' => false,
		'publicly_queryable'  => true,
		'show_ui'             => true,
		'show_in_nav_menus'   => true,
		'show_in_admin_bar'   => true,
		'show_in_rest'        => true,
		'capability_type'     => 'post',
		'hierarchical'        => true,
		'has_archive'         => true,
		'query_var'           => true,
		'can_export'          => true,
		'rewrite_no_front'    => false,
		'show_in_menu'        => true,
		'menu_position'       => 5,
		'menu_icon'           => 'dashicons-book',
		'supports' => [
			'title',
			'editor',
			'thumbnail',
			'comments',
			'page-attributes',
		],
		'taxonomies' => [
			'category',
			'tag',
			'Genre'
		],
		'rewrite' => true
	];

	register_post_type( 'manga', $args );
}

//Genre
add_action( 'init', 'genero' );
function genero() {
	$args = [
		'label'  => esc_html__( 'genero', 'mjmanga' ),
		'labels' => [
			'menu_name'                  => esc_html__( 'Genres', 'mjmanga' ),
			'all_items'                  => esc_html__( 'All Genres', 'mjmanga' ),
			'edit_item'                  => esc_html__( 'Edit Genre', 'mjmanga' ),
			'view_item'                  => esc_html__( 'View Genre', 'mjmanga' ),
			'update_item'                => esc_html__( 'Update Genre', 'mjmanga' ),
			'add_new_item'               => esc_html__( 'Add new Genre', 'mjmanga' ),
			'new_item'                   => esc_html__( 'New Genre', 'mjmanga' ),
			'parent_item'                => esc_html__( 'Parent Genre', 'mjmanga' ),
			'parent_item_colon'          => esc_html__( 'Parent Genre', 'mjmanga' ),
			'search_items'               => esc_html__( 'Search Genres', 'mjmanga' ),
			'popular_items'              => esc_html__( 'Popular Genres', 'mjmanga' ),
			'separate_items_with_commas' => esc_html__( 'Separate Genres with commas', 'mjmanga' ),
			'add_or_remove_items'        => esc_html__( 'Add or remove Genres', 'mjmanga' ),
			'choose_from_most_used'      => esc_html__( 'Choose most used Genres', 'mjmanga' ),
			'not_found'                  => esc_html__( 'No Genres found', 'mjmanga' ),
			'name'                       => esc_html__( 'Genres', 'mjmanga' ),
			'singular_name'              => esc_html__( 'Genre', 'mjmanga' ),
		],
		'public'               => true,
		'show_ui'              => true,
		'show_in_menu'         => true,
		'show_in_nav_menus'    => true,
		'show_tagcloud'        => true,
		'show_in_quick_edit'   => true,
		'show_admin_column'    => false,
		'show_in_rest'         => true,
		'hierarchical'         => false,
		'query_var'            => true,
		'sort'                 => false,
		'rewrite_no_front'     => false,
		'rewrite_hierarchical' => false,
		'rewrite' => array( 'slug' => 'genero' ),
	];
	register_taxonomy( 'genero', [ 'manga' ], $args );
}

	
	
	
	
	//PAGINATION READ
add_filter( 'get_next_post_join', 'navigate_in_same_taxonomy_join', 20);
add_filter( 'get_previous_post_join', 'navigate_in_same_taxonomy_join', 20 );
function navigate_in_same_taxonomy_join() {
	global $wpdb;
	return " INNER JOIN $wpdb->term_relationships AS tr ON p.ID = tr.object_id INNER JOIN $wpdb->term_taxonomy tt ON tr.term_taxonomy_id = tt.term_taxonomy_id";
}


add_filter( 'get_next_post_where' , 'navigate_in_same_taxonomy_where' );
add_filter( 'get_previous_post_where' , 'navigate_in_same_taxonomy_where' );
function navigate_in_same_taxonomy_where( $original ) {
	global $wpdb, $post;
	$where 		= '';
	$taxonomy  	= 'category';
	$op 		= ('get_previous_post_where' == current_filter()) ? '<' : '>';
	$where 		= $wpdb->prepare( "AND tt.taxonomy = %s", $taxonomy );
	if ( ! is_object_in_taxonomy( $post->post_type, $taxonomy ) )
		return $original ;

	$term_array = wp_get_object_terms( $post->ID, $taxonomy, array( 'fields' => 'ids' ) );

	$term_array = array_map( 'intval', $term_array );

	if ( ! $term_array || is_wp_error( $term_array ) )
		return $original ;

	$where 		= " AND tt.term_id IN (" . implode( ',', $term_array ) . ")";
	return $wpdb->prepare( "WHERE p.post_date $op %s AND p.post_type = %s AND p.post_status = 'publish' $where", $post->post_date, $post->post_type );
}

}
